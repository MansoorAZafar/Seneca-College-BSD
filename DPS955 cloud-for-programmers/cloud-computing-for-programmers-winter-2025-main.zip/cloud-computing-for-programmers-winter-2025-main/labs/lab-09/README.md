# Lab 9

In this lab we will explore how to use [AWS S3](https://aws.amazon.com/s3/) and the [Amazon AWS S3 JavaScript SDK](https://docs.aws.amazon.com/AWSJavaScriptSDK/v3/latest/clients/client-s3/index.html). We will also continue to practice working with `docker compose`, authoring compose files, and using Hurl to write more integration tests.

When you are done, you will have added [AWS S3](https://aws.amazon.com/s3/) support to your `fragments` microservice, and also created local and testing environments to validate it.

> [!WARNING]
> If you haven't already completed the [Elastic Container Service Deployment Walk-through](../../weeks/week-11/fragments-ecs-walkthrough.md), to set up your **Elastic Container Service** cluster, follow those steps **before** completing this lab, since we depend on it already working.

## AWS S3 Overview

[AWS S3](https://aws.amazon.com/s3/) is one of the oldest and most popular AWS services. It is designed to store unlimited amounts of data with high durability and availability, and do it cheaply. Whenever data storage is part of an application's architecture, [AWS S3](https://aws.amazon.com/s3/) is the very first service that should be considered.

A good way to think about [AWS S3](https://aws.amazon.com/s3/) is to imagine a **hash table** in the cloud: **key/value** pairs used to store and access data. [AWS S3](https://aws.amazon.com/s3/) is also known as an **object store**, since we use it to store objects (i.e., arbitrary **blobs** of binary data), for example:

- static web sites
- Docker images
- database backups
- videos
- machine learning models
- log files
- documents
- user-uploaded images
- "big data" data sets

You can store _any kind_ and _any amount_ of data (up to 5TB for an individual object). Each objects has a unique **key** value (i.e., a string, like a file path), and these **keys** are stored in uniquely named collections called **buckets**. You've used [AWS S3](https://aws.amazon.com/s3/) many times without knowing it. For example, when you submit an assignment on Blackboard, behind the scenes it's being uploaded to an S3 bucket.

There are lots of services that do something similar to [AWS S3](https://aws.amazon.com/s3/), namely, allow for storing arbitrary files in the cloud: [Dropbox](https://www.dropbox.com/), [Microsoft OneDrive](https://www.microsoft.com/en-ww/microsoft-365/onedrive/online-cloud-storage), [Google Drive](https://www.google.com/intl/en_ca/drive/), [iCloud Drive](https://www.icloud.com/iclouddrive), and many more. All of these services charge a monthly fee for a fixed amount of storage.

[AWS S3](https://aws.amazon.com/s3/) is different. While individuals can use it to store their data, the primary use case is to build back-end storage support into other applications. As a result, Amazon doesn't charge a monthly fee for a fixed amount of storage. Rather, [AWS S3](https://aws.amazon.com/s3/) provides an unlimited amount of storage, which is billed on-demand. Whether you use 300 bytes or 300 TB in a month, that's the amount you'll be billed. There are also different [storage classes](https://aws.amazon.com/s3/storage-classes/), which become even cheaper the less frequently you need to access the data.

Buckets and objects are managed via REST API calls to AWS. Various clients exist to help you create these requests: the [AWS Console](https://s3.console.aws.amazon.com/s3/home?region=us-east-1), the [AWS s3 CLI](https://awscli.amazonaws.com/v2/documentation/api/latest/reference/s3/index.html), or the [AWS SDK for JavaScript](https://docs.aws.amazon.com/AWSJavaScriptSDK/v3/latest/clients/client-s3/index.html).

We'll experiment with all three.

## 1. Create an S3 Bucket

Before you can work with [AWS S3](https://aws.amazon.com/s3/), you need to create a **bucket**. There are various ways to accomplish this, and we'll practice a few, beginning with the **AWS Console**.

1. Start the AWS Academy Learner Lab environment, and open the **AWS Console**
2. Search for **S3** in the list of services
3. Click **Create bucket**
4. Pick a name for your bucket. It must be between **3-63 characters** in length, and **must be unique**. For our purposes, choose something that uses your name, like `<seneca-username>-fragments`, for example: `david.humphrey-fragments`.
5. All buckets belong to a **region**, and we'll use `us-east-1`
6. For **Object Ownership**, we'll disable other accounts from accessing the objects: **ACLs disabled (recommended)**. We want to lock down our data as much as possible.
7. We'll also **Block all public access** to this bucket. It is possible to enable public access (e.g., to host a static web site from a bucket), but we'll mediate access to our bucket's objects via our `fragments` service (i.e., only it needs access).
8. We'll **Disable** the **Bucket Versioning** option
9. Amazon automatically encrypts all objects at rest in S3 buckets (this used to be optional), which adds extra security for our data. We'll use the default **Amazon S3 managed keys** to do it.
10. Click **Create bucket**

## 2. Manually Upload a File

Before we programmatically work with our bucket, we'll try working with it manually in the console.

1. Click on the bucket you just created in step 1
2. Click the **Upload** button
3. Click **Add files** and choose a file to upload (e.g., a text file, JavaScript file from your repo, an image, etc)
4. Click the **Upload** button to upload it. Notice the **Destination** URI you are given (e.g., `s3://david.humphrey-fragments`).
5. Confirm that the file has been added to your bucket.

## 3. Using the AWS S3 CLI

Next, let's try using the [AWS s3 CLI](https://awscli.amazonaws.com/v2/documentation/api/latest/reference/s3/index.html). Go back to the AWS Learner Lab web page.

1. In the **AWS Terminal**, at the prompt, enter the following command (NOTE: your prompt will look slightly different):

```sh
ddd_v1_w_ysZ_1002077@runweb52176:~$ aws s3 ls
```

2. You should see a list of your **Buckets**, including the bucket you created in step 1.
3. List the contents of the bucket, by including it in your command:

```sh
ddd_v1_w_ysZ_1002077@runweb52179:~$ aws s3 ls david.humphrey-fragments
```

4. Confirm that the file(s) you just uploaded are indeed listed in the bucket.
5. Delete the file. To do so, you'll need to use a full **S3 URI**, which takes the form: `s3://<bucket-name>/<file-name>`:

```sh
ddd_v1_w_ysZ_1002077@runweb52179:~$ aws s3 rm s3://david.humphrey-fragments/filename.txt
delete: s3://david.humphrey-fragments/filename.txt
```

## 4. Using the S3 SDK with fragments

Now that we have the basic idea, let's move toward using the [S3 AWS SDK for JavaScript](https://www.npmjs.com/package/@aws-sdk/client-s3), which is how we'll primarily work with [AWS S3](https://aws.amazon.com/s3/). All of the clients (console, cli, SDK) work the same way: they create HTTP requests and send commands to S3. The [S3 AWS SDK for JavaScript](https://www.npmjs.com/package/@aws-sdk/client-s3) helps us do this with JavaScript or TypeScript.

1. Start by installing `V3` of the [S3 AWS SDK for JavaScript](https://www.npmjs.com/package/@aws-sdk/client-s3):

> [!NOTE]
> There is also an [older version - https://www.npmjs.com/package/aws-sdk](https://www.npmjs.com/package/aws-sdk) that we will **not** use, and which you'll see used in various places on the web.

```sh
cd fragments
npm install --save @aws-sdk/client-s3
```

2. Previously, we created an in-memory data model for our backend. Now we're going to create a second one to work with AWS. To do this, make a copy of the `src/model/data/memory/*` directory in `src/model/data/aws/*`. Our `aws` data model will use the same module structure, but replace the in-memory database with [AWS S3](https://aws.amazon.com/s3/) (and eventually [DynamoDB](https://aws.amazon.com/dynamodb/)).
3. Update `src/model/data/index.js` so that it decides which backend data model to use at runtime, depending on whether an `AWS_REGION` is set in the environment. We'll use this variable as a cue to our server, so that it can use either the in-memory DB (i.e., no `AWS_REGION` set) or use AWS services (i.e., `AWS_REGION` is set):

```js
// src/model/data/index.js

// If the environment sets an AWS Region, we'll use AWS backend
// services (S3, DynamoDB); otherwise, we'll use an in-memory db.
module.exports = process.env.AWS_REGION ? require('./aws') : require('./memory');
```

4. Delete the file `src/model/data/aws/memory-db.js`, since we don't need it; replace it with a new file: `src/model/data/aws/s3Client.js`. This file will configure the [S3 SDK](https://docs.aws.amazon.com/AWSJavaScriptSDK/v3/latest/clients/client-s3/index.html), so that we can issues **commands**. We're going to write this code in such a way that we can easily swap the implementation of S3 that we use at runtime (e.g., use [LocalStack](https://localstack.cloud/) for testing). Most AWS SDK clients and CLI tools can use an `endpoint` URL, to override the service to use.

> [!IMPORTANT]
> To use localstack S3 vs. Amazon S3 with your `fragments` server, you'll have to specify `AWS_S3_ENDPOINT_URL=http://localhost:4566` in your environment to override the default.

```js
// src/model/data/aws/s3Client.js

/**
 * S3 specific config and objects.  See:
 * https://www.npmjs.com/package/@aws-sdk/client-s3
 */
const { S3Client } = require('@aws-sdk/client-s3');
const logger = require('../../../logger');

/**
 * If AWS credentials are configured in the environment, use them. Normally when we connect to S3
 * from a deployment in AWS, we won't bother with this.  But if you're testing locally, you'll need
 * these, or if you're connecting to LocalStack or MinIO
 * @returns Object | undefined
 */
const getCredentials = () => {
  if (process.env.AWS_ACCESS_KEY_ID && process.env.AWS_SECRET_ACCESS_KEY) {
    // See https://docs.aws.amazon.com/AWSJavaScriptSDK/v3/latest/clients/client-s3/modules/credentials.html
    const credentials = {
      accessKeyId: process.env.AWS_ACCESS_KEY_ID,
      secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
      // Optionally include the AWS Session Token, too (e.g., if you're connecting to AWS from your laptop).
      // Not all situations require this, so we won't check for it above, just use it if it is present.
      sessionToken: process.env.AWS_SESSION_TOKEN,
    };
    logger.debug('Using extra S3 Credentials AWS_ACCESS_KEY_ID and AWS_SECRET_ACCESS_KEY');
    return credentials;
  }
};

/**
 * If an AWS S3 Endpoint is configured in the environment, use it.
 * @returns string | undefined
 */
const getS3Endpoint = () => {
  if (process.env.AWS_S3_ENDPOINT_URL) {
    logger.debug({ endpoint: process.env.AWS_S3_ENDPOINT_URL }, 'Using alternate S3 endpoint');
    return process.env.AWS_S3_ENDPOINT_URL;
  }
};

/**
 * Configure and export a new s3Client to use for all API calls.
 * NOTE: we want to use this client with both AWS S3, but also
 * MinIO and LocalStack in development and testing. We may or may
 * not have various configuration settings, and will pass
 * `undefined` when we don't (i.e. we'll ignore them).
 */
module.exports = new S3Client({
  // The region is always required
  region: process.env.AWS_REGION,
  // Credentials are optional (only MinIO needs them, or if you connect to AWS remotely from your laptop)
  credentials: getCredentials(),
  // The endpoint URL is optional
  endpoint: getS3Endpoint(),
  // We always want to use path style key names
  forcePathStyle: true,
});
```

5. In `src/model/data/aws/index.js`, update the `require()` path for the `MemoryDB` module. Even though we're switching to use [S3](https://aws.amazon.com/s3/) for our fragment **data**, we still need to use the `MemoryDB` for our fragment **metadata**, since we haven't added [DynamoDB](https://aws.amazon.com/dynamodb/) yet (i.e., we'll continue to fake some parts of our AWS backend). The updated code should look like this:

```js
// XXX: temporary use of memory-db until we add DynamoDB
const MemoryDB = require('../memory/memory-db');
```

6. In `src/model/data/aws/index.js`, modify the `writeFragmentData` function to use our `s3Client` and the [`PutObjectCommand` from the SDK](https://docs.aws.amazon.com/AWSJavaScriptSDK/v3/latest/clients/client-s3/classes/putobjectcommand.html). An S3 `PUT` command **sends data to a bucket**, and needs to be configured with the **bucket name**, a **key**, and the **data** (i.e., a `Buffer`):

```js
const s3Client = require('./s3Client');
const { PutObjectCommand } = require('@aws-sdk/client-s3');

...

// Writes a fragment's data to an S3 Object in a Bucket
// https://github.com/awsdocs/aws-sdk-for-javascript-v3/blob/main/doc_source/s3-example-creating-buckets.md#upload-an-existing-object-to-an-amazon-s3-bucket
async function writeFragmentData(ownerId, id, data) {
  // Create the PUT API params from our details
  const params = {
    Bucket: process.env.AWS_S3_BUCKET_NAME,
    // Our key will be a mix of the ownerID and fragment id, written as a path
    Key: `${ownerId}/${id}`,
    Body: data,
  };

  // Create a PUT Object command to send to S3
  const command = new PutObjectCommand(params);

  try {
    // Use our client to send the command
    await s3Client.send(command);
  } catch (err) {
    // If anything goes wrong, log enough info that we can debug
    const { Bucket, Key } = params;
    logger.error({ err, Bucket, Key }, 'Error uploading fragment data to S3');
    throw new Error('unable to upload fragment data');
  }
}
```

7. Next, modify the `readFragmentData` function to use our `s3Client` and the [`GetObjectCommand` from the SDK](https://docs.aws.amazon.com/AWSJavaScriptSDK/v3/latest/clients/client-s3/classes/getobjectcommand.html). An S3 `GET` command **retrieves an object from a bucket**, and needs to be configured with the **bucket's name** and an object's **key**. It returns a [stream](https://nodejs.org/api/stream.html#stream) that we can use to get our data out of S3. Streams are a more efficient way to pass large amounts of data around without having to hold everything in memory. Instead of sending the data all at once, it flows a bit at a time, until we have it all. Since our API uses `Buffer`s vs. `stream`s, we'll need to convert the `stream` into a `Buffer` before returning it, by reading all the data from the stream and then creating a new `Buffer`:

> [!NOTE]
> You could rewrite your Express code to `pipe` the `stream` to `res`, but I'll leave that to you if you're interested.

```js
const { PutObjectCommand, GetObjectCommand } = require('@aws-sdk/client-s3');

...

// Convert a stream of data into a Buffer, by collecting
// chunks of data until finished, then assembling them together.
// We wrap the whole thing in a Promise so it's easier to consume.
const streamToBuffer = (stream) =>
  new Promise((resolve, reject) => {
    // As the data streams in, we'll collect it into an array.
    const chunks = [];

    // Streams have events that we can listen for and run
    // code.  We need to know when new `data` is available,
    // if there's an `error`, and when we're at the `end`
    // of the stream.

    // When there's data, add the chunk to our chunks list
    stream.on('data', (chunk) => chunks.push(chunk));
    // When there's an error, reject the Promise
    stream.on('error', reject);
    // When the stream is done, resolve with a new Buffer of our chunks
    stream.on('end', () => resolve(Buffer.concat(chunks)));
  });

// Reads a fragment's data from S3 and returns (Promise<Buffer>)
// https://github.com/awsdocs/aws-sdk-for-javascript-v3/blob/main/doc_source/s3-example-creating-buckets.md#getting-a-file-from-an-amazon-s3-bucket
async function readFragmentData(ownerId, id) {
  // Create the PUT API params from our details
  const params = {
    Bucket: process.env.AWS_S3_BUCKET_NAME,
    // Our key will be a mix of the ownerID and fragment id, written as a path
    Key: `${ownerId}/${id}`,
  };

  // Create a GET Object command to send to S3
  const command = new GetObjectCommand(params);

  try {
    // Get the object from the Amazon S3 bucket. It is returned as a ReadableStream.
    const data = await s3Client.send(command);
    // Convert the ReadableStream to a Buffer
    return streamToBuffer(data.Body);
  } catch (err) {
    const { Bucket, Key } = params;
    logger.error({ err, Bucket, Key }, 'Error streaming fragment data from S3');
    throw new Error('unable to read fragment data');
  }
}
```

8. Now it's your turn. Follow the same pattern we've used above in order to update the `deleteFragment` function. Currently, it deletes the fragment's metadata **and** data from the in-memory db. Change it so that the **data** gets deleted from S3. If you haven't already implemented the `DELETE /fragments/:id` route in the assignment spec, you should do that now too, so you can test that everything works.

## 5. Write an Integration Test

At this point you have modified your `fragments` server to use [AWS S3](https://aws.amazon.com/s3/), but does it work? It's hard to know until we write a test! We could rely on our unit tests, but they won't tell us if our new code works in combination with [AWS S3](https://aws.amazon.com/s3/).

Using what you learned in the previous lab, write a new **integration test** named `tests/integration/lab-9-s3.hurl`. This test will make sure that the following steps all work together (i.e., do each of these steps and checks one after the other in the same `.hurl` file):

1. `POST` a new text `fragment` to `http://localhost:8080` as an authorized user. The fragment's body should be the string, `Hello S3!`.
2. Confirm that the server returns a `201`, and **capture** the **Location** header value to a variable named `url`
3. `GET` the `fragment` you just created using the `url` as an authorized user.
4. Confirm that the server returns a `200`, that the type of the fragment is `text/plain`, and that the `body` is equal to `Hello S3!`
5. `DELETE` the `fragment` using the `url` as an authorized user.
6. Confirm that the server returns a `200`.
7. Try to `GET` the `fragment` again using the `url` as an authorized user.
8. Confirm that the server returns a `404`, since the fragment should be deleted.

In order to run this test, we need to run our server so it has access to `S3`. We could try to get this code working against the real S3, but doing so would require you to `push`, `tag`, and `deploy` your code to Elastic Container Service over and over again until you get all bugs worked out. The process would not be fun!

A better way is to use a local S3 server to simulate AWS.

## 6. Using LocalStack for S3 Development

In our previous lab, we created `docker-compose.yml` and set up a [LocalStack](https://localstack.cloud/) service to run a local version of AWS S3. We also created a script, `scripts/local-aws-setup.sh` to set up our AWS resources in [LocalStack](https://localstack.cloud/) (e.g., create an S3 bucket).

We'll use these now to test and debug our integration test and S3 code.

1. Start the Docker containers for your offline setup, and have `docker compose` re-build your `fragments` image (i.e., use the `--build` flag):

```sh
cd fragments
docker compose up --build -d
```

2. In a Unix shell, run the `scripts/local-aws-setup.sh` script to create your `fragments` bucket:

> [!IMPORTANT]
> You will need to do this **every** time you (re)start the containers, since they don't store any data to disk.

```sh
$ ./scripts/local-aws-setup.sh
Setting AWS environment variables for LocalStack
AWS_ACCESS_KEY_ID=test
AWS_SECRET_ACCESS_KEY=test
AWS_SESSION_TOKEN=test
AWS_DEFAULT_REGION=us-east-1
Waiting for LocalStack S3...
LocalStack S3 Ready
Creating LocalStack S3 bucket: fragments
{
    "Location": "/fragments"
}
Creating DynamoDB-Local DynamoDB table: fragments
{
    "TableDescription": {
        "AttributeDefinitions": [
            {
                "AttributeName": "ownerId",
                "AttributeType": "S"
            },
            {
                "AttributeName": "id",
                "AttributeType": "S"
            }
        ],
        "TableName": "fragments",
        "KeySchema": [
            {
                "AttributeName": "ownerId",
                "KeyType": "HASH"
            },
            {
                "AttributeName": "id",
                "KeyType": "RANGE"
            }
        ],
        "TableStatus": "ACTIVE",
        "CreationDateTime": "2022-03-27T18:15:52.966000-04:00",
        "ProvisionedThroughput": {
            "LastIncreaseDateTime": "1969-12-31T19:00:00-05:00",
            "LastDecreaseDateTime": "1969-12-31T19:00:00-05:00",
            "NumberOfDecreasesToday": 0,
            "ReadCapacityUnits": 10,
            "WriteCapacityUnits": 5
        },
        "TableSizeBytes": 0,
        "ItemCount": 0,
        "TableArn": "arn:aws:dynamodb:ddblocal:000000000000:table/fragments"
    }
}
```

3. In another terminal, start streaming the logs from your `fragments` server, so you can see what's happening when the tests run. Use `docker ps` to find your `fragments` service, and get its `CONTAINER ID`, which will look something like `26bf87fafef5`. Use that `CONTAINER ID` to get logs for the container:

```sh
docker ps
docker logs -f 26bf87fafef5
```

> [!TIP]
> You could skip the `docker ps` part by giving your container a name in the `docker-compose.yml` file, see the [docs for `container_name`](https://docs.docker.com/compose/compose-file/compose-file-v3/#container_name).

4. In another terminal, run your integration test with `hurl`:

```sh
$ cd fragments
$ npm run test:integration
tests/integration/lab-9.hurl: RUNNING [1/1]
tests/integration/lab-9.hurl: SUCCESS
--------------------------------------------------------------------------------
Executed:  1
Succeeded: 1 (100.0%)
Failed:    0 (0.0%)
Duration:  100ms
```

If your test doesn't pass, look at the line that is failing and figure out which part of the test is not working. Use that to debug your server. You should inspect your logs for any clues as well.

Whenever you make changes to your server code, you'll need to rebuild and restart your `fragments` container. However, we don't need/want to restart the other containers, which are running fine. You can do that using the `--no-deps` option, and passing the `fragments` service name in order to rebuild/restart without touching the other containers:

```sh
docker compose up --build --no-deps -d fragments
```

5. When you have your test passing, stop your containers using the following:

```sh
docker compose down
```

## 7. Configure and Deploy to AWS

Now that you know that your S3 code is working, let's deploy an updated version of our service to Elastic Container Service (ECS) that uses it. Using what you learned a few weeks ago in the [Elastic Container Service Deployment Walk-through](../../weeks/week-11/fragments-ecs-walkthrough.md), we'll `tag` a new **minor** release of our code and deploy it.

### Understanding ECS and IAM Roles

The first thing we'll need to update is the security permissions between the ECS container(s) we'll run and our new S3 Bucket. By default, these resources do **not** have access to one another. We have to grant explicit access in the form of a AWS Credentials or an [IAM Role](https://docs.aws.amazon.com/IAM/latest/UserGuide/id_roles.html). Where AWS Credentials let an individual log into an AWS account and use its resources, an IAM Role is a set of permissions that a particular user can assume. By _assuming_ a role, we inherit the permissions assigned to that role.

In the AWS Learner Lab, we've been using the `LabRole` whenever we created new resources. Doing so means that we can share access between resources, since they all share the same IAM role. The `LabRole` IAM role is pre-defined for us, and allows AWS resources we create in our account to be used together.

In the [ECS Walthrough](../../weeks/week-11/fragments-ecs-walkthrough.md) we defined a GitHub Actions Workflow step to "render" our ECS task definition JSON like so (pay attention to the `AWS_*` keys in the `environment-variables` section in particular):

```yml
# We need to update our fragment's Task Definition JSON
# (i.e., fragments-definition.json) to use the newly
# updated Docker Image to use (i.e., the tag we just pushed to ECR).
# We can also update/set the environment variables if we want.
- name: Fill in the new image ID in the Amazon ECS task definition
  id: update-task-def
  uses: aws-actions/amazon-ecs-render-task-definition@v1
  env:
    ECR_REGISTRY: ${{ steps.login-ecr.outputs.registry }}
    ECR_REPO: fragments
    VERSION_TAG: ${{ github.ref_name }}
  with:
    task-definition: fragments-definition.json
    container-name: fragments
    # Use the image we just built and pushed to ECR for this tag
    image: ${{ env.ECR_REGISTRY }}/${{ env.ECR_REPO }}:${{ env.VERSION_TAG }}
    # Add all the necessary environment variables, using GitHub Encrypted Secrets
    # for any values that should not be checked into git directly.  Here are
    # a few to get you started, but you should fill in the rest yourself.
    environment-variables: |
      LOG_LEVEL=info
      NODE_ENV=production
      AWS_ACCESS_KEY_ID=${{ secrets.AWS_ACCESS_KEY_ID }}
      AWS_SECRET_ACCESS_KEY=${{ secrets.AWS_SECRET_ACCESS_KEY }}
      AWS_SESSION_TOKEN=${{ secrets.AWS_SESSION_TOKEN }}
      # ...continue the rest here...
```

In the `environment-variable` section, we previously passed our AWS credentials to use in order to have them get added to the task definition JSON. Doing so includes them in our container when it runs. This works, but only temporarily, since the `AWS_SESSION_TOKEN` will expire, and the credentials need to get updated. There's a better way!

Another approach we can take is to have our ECS container(s) assume the `LabRole` IAM role when started. If you look at your `fragments-definition.json` file in your editor, you'll notice the following lines (yours will use different values):

```json
{
  "ipcMode": null,
  "executionRoleArn": "arn:aws:iam::247962128096:role/LabRole",
  ...
  "taskRoleArn": null,
  ...
}
```

Here you can see the `LabRole` being used as the [ECS Task Execution Role](https://docs.aws.amazon.com/AmazonECS/latest/developerguide/task_execution_IAM_role.html), and nothing being used for the [ECS Task Role](https://docs.aws.amazon.com/AmazonECS/latest/developerguide/task-iam-roles.html). We assign the IAM role we want to use via an [Amazon Resource Name (ARN)](https://docs.aws.amazon.com/general/latest/gr/aws-arns-and-namespaces.html), which are unique identifiers (i.e., "use the `LabRole` in _my_ account, not the `LabRole` in someone else's account").

ECS uses these two different roles as follows:

1. **Execution Role**: used to make AWS API calls **during deployment** (e.g., to pull your Docker image from ECR)
2. **Task Role**: used to make AWS API calls **during runtime** (e.g., to access an S3 Bucket or DynamoDB table from a running container)

Our `fragments-definition.json` already uses our `LabRole` for deployment (i.e., `executionRoleArn`), but we need to **also** use it during runtime. Let's modify the file to update the `taskRoleArn` (use your `LabRole`'s specific ARN value vs. what is listed below):

```json
{
  "ipcMode": null,
  "executionRoleArn": "arn:aws:iam::247962128096:role/LabRole",
  ...
  "taskRoleArn": "arn:aws:iam::247962128096:role/LabRole",
  ...
}
```

Now we can remove the AWS Learner Lab account credentials from our environment variables (i.e., remove `AWS_ACCESS_KEY_ID`, `AWS_SECRET_ACCESS_KEY`, `AWS_SESSION_TOKEN` but leave the `AWS_COGNITO_*` and other configuration variables) in the render task definition step, since we'll use the `LabRole` at runtime via the ECS Task Role we just set:

```yml
    uses: aws-actions/amazon-ecs-render-task-definition@v1
      ...
      environment-variables: |
        LOG_LEVEL=info
        NODE_ENV=production
        # ...continue the rest here...
```

When our container runs, the [AWS JavaScript SDK will use the `LabRole`'s permissions](https://docs.aws.amazon.com/sdk-for-javascript/v3/developer-guide/setting-credentials-node.html) to run our API requests (e.g., connect to our S3 Bucket).

### Adding S3 to our ECS Config

After our security is properly setup, we also need to configure ECS to use our S3 bucket.

1. Add your S3 Bucket name (from step 1 above) as an environment variable, `AWS_S3_BUCKET_NAME`, to our `fragments-definition.json` task definition file. You could also do this in your `.github/workflows/cd.yml` file under the [aws-actions/amazon-ecs-render-task-definition](https://github.com/aws-actions/amazon-ecs-render-task-definition) action if you want (either way will work). Since this isn't a secret, and won't be changing, hard-coding it into `fragments-definition.json` is safe.
2. Update your local git repo with all the changes you've made (i.e., `add`, `commit`) and `push` to run your CI workflow. Once it passes, create a new `tag` (i.e., `0.9.0`, since this is lab 9):

```sh
npm version 0.9.0
```

3. In your `fragments` GitHub Repo, update your **GitHub Actions Secrets** for your current lab session's **AWS Credentials** (recall that these change every time you restart the Learner Lab). Get your `aws_access_key_id`, `aws_secret_access_key` and `aws_session_token` from the Learner Lab (i.e., under **AWS Details** and the **AWS CLI** button) and use the current values to update your **GitHub Actions Secrets**: in your `fragments` repo go to **Settings** > **Secrets** > **Actions** and click **Update** beside each secret to be updated.
4. Push your new `tag` to GitHub in order to trigger a deployment via your **Continuous Delivery Workflow**:

```sh
git push origin main --tags
```

5. Switch to the **Actions** tab of your `fragments` repo on GitHub, and watch the workflow run. Make sure that it passes. If you run into issues, fix any problems locally, `add` and `commit` the changes, then create another **patch** version tag (e.g., `0.9.1`, `0.9.2`) using `npm version patch`, and `push` with `--tags`. Repeat until you can deploy your application correctly.
6. Update your `fragments-ui` web app so it uses your **Elastic Container Service** deployment as the backend by changing the `API_URL` it is configured to use (i.e., use the **Elastic Container Service Load Balancer URL** instead of <http://localhost:8080>).
7. Try running your `fragments-ui` front-end locally, and create a new fragment.
8. In the **AWS Console** for **S3** navigate to your **bucket** and make sure you can see that the fragment **object** has been created. It will have a **key** like `63258595765642a14e8a725a22b18eab2ae02882a1e13525c6f500532eaa31f5/524RQdhMzifPRhlKI1G-V` (i.e., `ownerId/fragment-id`).

## 8. [OPTIONAL] Using MinIO for Local S3 Development

In addition to [LocalStack](https://localstack.cloud/), another popular choice for local S3 development is [MinIO](https://min.io), an S3-compatible object store that can be run as a Docker container locally. It's a useful tool for development, or creating private-cloud applications that need S3 object storage.

You can easily create your own [MinIO](https://min.io) server using `docker compose`.

1. In the root of your `fragments` server, create a new **compose** file named `docker-compose.local.yml` (we'll use `.local.` as a cue to remind us that this is for local development).
2. Add the following to `docker-compose.local.yml`. Pay attention to a few things. First, we need to configure our `fragments` server to know about the [MinIO](https://min.io) server, which will be running on `http://localhost:9000`. It will also run a web console on `http://localhost:9001`. Next, we have to set a username and password for [MinIO](https://min.io), which will be the same values we use as our `AWS_ACCESS_KEY_ID` and `AWS_SECRET_ACCESS_KEY`. In the file below, we're using terrible keys, but we aren't going to deploy this to production. If you did, you'd need to set proper keys! Finally, we're also going to mount a `volume` at `./minio/data` in our host to `/data` in the [MinIO](https://min.io) server. This means we can store our bucket and objects on disk, and they will survive starting/stopping the container

```yml
# docker-compose.local.yml for Local development
services:
  fragments:
    init: true
    build: .
    environment:
      # Our API will be running on http://localhost:8080
      - API_URL=http://localhost:8080
      # Use Basic Auth (for running tests, CI)
      - HTPASSWD_FILE=tests/.htpasswd
      # Use the LOG_LEVEL set in the host environment, or default to debug
      - LOG_LEVEL=${LOG_LEVEL:-debug}
      # AWS credentials to use
      - AWS_ACCESS_KEY_ID=minio-access-key
      - AWS_SECRET_ACCESS_KEY=minio-secret-key
      - AWS_REGION=us-east-1
      # Use minio as our S3 endpoint
      - AWS_S3_ENDPOINT_URL=http://minio:9000
      - AWS_S3_BUCKET_NAME=${AWS_S3_BUCKET_NAME:-fragments}
    ports:
      - '8080:8080'

  minio:
    image: minio/minio
    command: server --console-address ":9001" /data
    ports:
      # The minio API endpoint
      - '9000:9000'
      # The minio web console endpoint
      - '9001:9001'
    environment:
      # See https://docs.min.io/minio/baremetal/reference/minio-server/minio-server.html#environment-variables
      # Root user (Access Key, typically a long, random string)
      - MINIO_ROOT_USER=minio-access-key
      # Root user's password (Secret Key, typically a long, random string)
      - MINIO_ROOT_PASSWORD=minio-secret-key
    volumes:
      # Use what's in `./minio/data` as the storage volume
      # NOTE: add this to your .gitignore
      - ./minio/data:/data
```

3. Start your containers:

> [!NOTE]
> We are using a different filename for our `docker-compose.yml`, so we indicate that with the `-f` flag.

```sh
cd fragments
docker compose -f docker-compose.local.yml up -d
```

4. Log in to the [MinIO](https://min.io) console (similar to the AWS S3 Console) by going to <http://localhost:9001>, and using the `MINIO_ROOT_USER` and `MINIO_ROOT_PASSWORD` values you entered above.
5. Create a new bucket by clicking the **Create Bucket** button.
6. Choose a name for your bucket, for example `fragments` (which we set as the default in `docker-compose.local.yml` above) and click **Create Bucket**.
7. Add a file to your bucket by clicking the **Upload** button and choosing a file to upload.
8. Look at the `minio/data` directory on your host, and you should see a new folder with the same name as the bucket you just created, and the file you uploaded. Anything you put in this bucket will get stored in this location (i.e., outside of the container).
9. Add the `minio/` directory to your `.gitignore` file.
10. Stop your containers

```sh
docker compose -f docker-compose.local.yml down
```

10. Restart your containers:

```sh
docker compose -f docker-compose.local.yml up -d
```

11. Log in to the MinIO Console at <http://localhost:9001> using the same username and password as before, and confirm that the bucket and object are still there.

You can now use S3 locally and have your data survive starting/stopping the containers. This is an ideal setup for local development, since you also get a console for viewing your data.

## Submission

- Link to your completed `tests/integration/lab-9-s3.hurl` in your `fragments` GitHub repo
- Screenshot of your `tests/integration/lab-9-s3.hurl` test passing, when run against your `fragments` server and `LocalStack` using `docker compose` (i.e., show the terminal(s) running the necessary commands to make this happen)
- Screenshot of your `fragments-ui` creating a fragment using your **Elastic Container Service** deployment (i.e., show the **Network** tab to prove which back-end service is being used)
- Screenshot of the **AWS S3 Console** showing the fragment you just created in S3 as an object in your bucket (i.e., prove that you've been able to create the fragment data in S3)
- [OPTIONAL] Screenshot of your MinIO console running a local S3 server.
