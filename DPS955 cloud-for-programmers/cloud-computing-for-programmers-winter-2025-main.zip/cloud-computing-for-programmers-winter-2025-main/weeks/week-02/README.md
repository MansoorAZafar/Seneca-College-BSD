# Week 2

## Lectures

1. Introduction to the AWS Learner Lab, Amazon Cognito, OAuth2, and Amplify <https://www.youtube.com/watch?v=U0-5ziBQxzg>
1. Working with Environment Variables and Environment Files <https://www.youtube.com/watch?v=-AoOwqR_-78>
1. Understanding Passport.js and Cognito JWT Bearer Token Auth <https://www.youtube.com/watch?v=h8te5AmRZcc>

## Readings

- **Learner Lab - Student Guide.pdf** (available in AWS Academy Learner Lab)
- [Amazon Cognito](https://aws.amazon.com/cognito/). The following docs are referenced heavily in this week's lab, and you might want to read through them for background:
  - [Amazon Cognito Developer Guide](https://docs.aws.amazon.com/cognito/latest/developerguide)
  - [Getting started with user pools](https://docs.aws.amazon.com/cognito/latest/developerguide/getting-started-with-cognito-user-pools.html)
  - [AWS Amplify Auth](https://docs.amplify.aws/lib/auth/getting-started/q/platform/js/#option-1-use-pre-built-ui-components)
  - [AWS Amplify UI for Frameworks](https://ui.docs.amplify.aws/react/getting-started/installation)
- Refreshers and Background on Authentication and Authorization:
  - Understanding [OAuth2 and Single-Page Apps](https://www.oauth.com/oauth2-servers/single-page-apps/)
  - [Introduction to JSON Web Tokens](https://jwt.io/introduction)
- [Topic Demos and Discussions](discussion.md)

## TODO

- Get set up with your **AWS Academy Learner Lab** account. Everyone should have received an invitation email. Please following the instructions to create your account. If you have problems, let your professor know ASAP.
- Complete [Lab 2](../../labs/lab-02/README.md). This lab will take you most of the week, so begin early. The readings above are background to help you with the lab.
- Use the course [Discussions](https://github.com/humphd/cloud-computing-for-programmers-winter-2025/discussions/) to get help with your lab
- Finish reading the [Fragments Microservice Specification](../../assignments/README.md) if you haven't already
- Finish reading [Assignment 1](../../assignments/assignment-01/README.md) if you haven't already
