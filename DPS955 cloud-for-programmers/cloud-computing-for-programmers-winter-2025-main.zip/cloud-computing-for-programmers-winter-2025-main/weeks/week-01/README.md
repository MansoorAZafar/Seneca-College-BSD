# Week 1

## Lectures

1. Course Introduction - <https://www.youtube.com/watch?v=i9_PFhnvxWg>
1. Discussion of Structured Logging - <https://www.youtube.com/watch?v=OzATfSfR3ls>
1. Discussion of Semver and Supply Chain Security - <https://www.youtube.com/watch?v=FzEX-xttHBk>

## Readings

- [Course Design and Introduction](course-design-and-intro.md)
- [What is Cloud Computing?](what-is-cloud-computing.md)
- [What is a Microservice?](microservices.md)
- [Topic Demos and Discussions](demos.md)

## TODO

- Get set up with [GitHub access to the course](https://github.com/humphd/cloud-computing-for-programmers-winter-2025)
- Read through the [Course Schedule](../../README.md)
- Watch the Week 1 Lectures (see above)
- Do the Week 1 Readings (see above)
- Locate the course [Discussions](https://github.com/humphd/cloud-computing-for-programmers-winter-2025/discussions/) and [reply to the first post and introduce yourself](https://github.com/humphd/cloud-computing-for-programmers-winter-2025/discussions/1)
- Complete [Lab 1](../../labs/lab-01/README.md)
- Begin reading the [Fragments Microservice Specification](../../assignments/README.md)
- Begin reading [Assignment 1](../../assignments/assignment-01/README.md)
