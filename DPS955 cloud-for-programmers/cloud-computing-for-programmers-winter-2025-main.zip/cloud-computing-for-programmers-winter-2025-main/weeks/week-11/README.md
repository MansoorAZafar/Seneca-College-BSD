# Week 11

## Lectures

1. Object Storage in the cloud and Amazon S3 - <https://www.youtube.com/watch?v=OeTl6o-nRxI>
2. Working with S3 offline using `docker compose` and understanding S3 Signed URLs - <https://www.youtube.com/watch?v=IDHXynaMDys>

## Readings and References

- [History and Architecture of S3](https://www.allthingsdistributed.com/2023/07/building-and-operating-a-pretty-big-storage-system.html)
- [Amazon AWS S3](https://aws.amazon.com/s3/)
  - [Getting Started with Amazon S3](https://aws.amazon.com/s3/getting-started/?nc=sn&loc=6&dn=1)
  - [S3 Developer Guide](https://docs.aws.amazon.com/AmazonS3/latest/userguide//Welcome.html)
- [Amazon AWS S3 JavaScript SDK](https://docs.aws.amazon.com/AWSJavaScriptSDK/v3/latest/clients/client-s3/index.html)
- [AWS s3 CLI](https://awscli.amazonaws.com/v2/documentation/api/latest/reference/s3/index.html)
- [IAM Roles](https://docs.aws.amazon.com/IAM/latest/UserGuide/id_roles.html) and understanding and using the AWS Learn Lab `LabRole` IAM role
- [node.js streams](https://nodejs.org/api/stream.html#stream)
- [Discussion and Demo](discussion-and-demo.md)

## TODO

- Complete the [Elastic Container Service, GitHub Actions, and fragments Walk-Through](fragments-ecs-walkthrough.md)
- Complete [Lab 9](../../labs/lab-09/README.md)
- Continue working on [Assignment 3](../../assignments/assignment-03/README.md)
- BONUS: after you have set up your ECS cluster and Load Balancer, you can consider doing the optional [My.Custom.Domain Walkthrough](./mycustomdomain-walkthrough.md) to create a custom domain name, SSL certificate, and secure your service on AWS
