# Week 7

## Lectures

1. Best practices for writing Dockerfiles - <https://www.youtube.com/watch?v=X5IoVNsfJ0Q>
1. Example walkthrough of Dockerizing a web app - <https://www.youtube.com/watch?v=0ZWKfJv7XEA>

## Readings and References

- [Dockerfile Reference](https://docs.docker.com/engine/reference/builder)
- [Best Practices for Writing Dockerfiles](https://docs.docker.com/develop/develop-images/dockerfile_best-practices/)
- [Use multi-stage builds](https://docs.docker.com/develop/develop-images/multistage-build/)
- [Docker Optimization 5-Part Guide](https://www.augmentedmind.de/2022/01/09/optimize-docker-development-speed/)
- [10 best practices to containerize Node.js web applications with Docker](https://snyk.io/blog/10-best-practices-to-containerize-nodejs-web-applications-with-docker/)
  - [Cheatsheet (PDF)](https://res.cloudinary.com/snyk/images/v1/wordpress-sync/NodeJS-CheatSheet/NodeJS-CheatSheet.pdf)
- [Docker Hub](https://hub.docker.com/)
- Case Study: Dockerize <https://github.com/Seneca-ICTOER/Intro2C>
  - [Docusaurus](https://docusaurus.io/)
  - [yarn](https://classic.yarnpkg.com/en/)
  - [nginx](https://docs.nginx.com/nginx/admin-guide/installing-nginx/installing-nginx-open-source/)
  - [Dockerfile](Dockerfile)
  - [.dockerignore](.dockerignore)

## TODO

- Complete [Lab 6](../../labs/lab-06/README.md)
- Work on [Assignment 2](../../assignments/assignment-02/README.md)
